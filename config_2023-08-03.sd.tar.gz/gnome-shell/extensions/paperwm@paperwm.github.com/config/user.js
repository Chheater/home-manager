// -*- mode: gnome-shell -*-
const Extension = imports.misc.extensionUtils.getCurrentExtension();
const Tiling = Extension.imports.tiling;
const Keybindings = Extension.imports.keybindings;

function enable() {
    // Runs when extension is enabled
}

function disable() {
    // Runs when extension is disabled
}
