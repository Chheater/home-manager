Extract me to ~/.themes
or to ~/.local/share/themes